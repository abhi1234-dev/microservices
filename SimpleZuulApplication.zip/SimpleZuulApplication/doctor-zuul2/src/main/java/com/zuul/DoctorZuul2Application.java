package com.zuul;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DoctorZuul2Application {

	public static void main(String[] args) {
		SpringApplication.run(DoctorZuul2Application.class, args);
	}

}
