package com.zuul;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DoctorServiceController {

	@GetMapping("/getDS")
	public String getDoctorService(){
		return "Doctor Microservice first function";
	}
	@GetMapping("/callDoctor/{name}")
	public String callDoctor(@PathVariable String name){
		return "It's an Emergency "+name;
	}
}
