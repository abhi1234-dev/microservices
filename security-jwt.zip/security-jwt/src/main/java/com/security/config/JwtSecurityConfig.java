package com.security.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.ProviderManager;
import org.springframework.security.config.annotation.method.configuration.EnableGlobalMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.annotation.web.configurers.SessionManagementConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;

import com.security.security.JwtAuthenticationEntryPoint;
import com.security.security.JwtAuthenticationProvider;
import com.security.security.JwtAuthenticationTokenFilter;
import com.security.security.JwtSuccessHandler;

import io.jsonwebtoken.lang.Collections;

@Configuration
@EnableWebSecurity
@EnableGlobalMethodSecurity(prePostEnabled=true)
public class JwtSecurityConfig extends WebSecurityConfigurerAdapter{

	/*
	 * Authentication Manager is provided by spring
	 * we will create a custom Authentication manager
	 * we need to override provider manager with custom authentication provider
	 */
	@Autowired
	private JwtAuthenticationProvider authenticationProvider;
	@Autowired
	private JwtAuthenticationEntryPoint entryPoint;

	@Bean
	public AuthenticationManager authenticationManager(){
		return new ProviderManager(java.util.Collections.singletonList(authenticationProvider));
		
	}
	
	@Bean
	public JwtAuthenticationTokenFilter authenticationTokenFilter(){
	
		//Jwt authentication token filter
		JwtAuthenticationTokenFilter filter=new JwtAuthenticationTokenFilter();
		filter.setAuthenticationManager(authenticationManager());
		filter.setAuthenticationSuccessHandler(new JwtSuccessHandler());
		return filter;
	}
	/*
	 * Configuring Http sucurity filter
	 */
	@Override
	protected void configure(HttpSecurity http) throws Exception {
		http.csrf().disable()
		.authorizeRequests().antMatchers("**/rest/**").authenticated()
		.and().exceptionHandling().authenticationEntryPoint(entryPoint)
		.and()
		.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
		http.addFilterBefore(authenticationTokenFilter(), UsernamePasswordAuthenticationFilter.class);
		 http.headers().cacheControl();
	}
	
	
}
