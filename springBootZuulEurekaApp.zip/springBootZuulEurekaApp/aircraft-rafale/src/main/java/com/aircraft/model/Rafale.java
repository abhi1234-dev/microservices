package com.aircraft.model;

public class Rafale {

	private int fighterId;
	private String model;
	private String pilotName;
	private String role;
	private String nationalOrigin;
	private String manufacturer;
	private String designer;
	private String primaryUser;
	
	public Rafale(){
		
	}

	public int getFighterId() {
		return fighterId;
	}

	public void setFighterId(int fighterId) {
		this.fighterId = fighterId;
	}

	public String getModel() {
		return model;
	}

	public void setModel(String model) {
		this.model = model;
	}

	public String getPilotName() {
		return pilotName;
	}

	public void setPilotName(String pilotName) {
		this.pilotName = pilotName;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getNationalOrigin() {
		return nationalOrigin;
	}

	public void setNationalOrigin(String nationalOrigin) {
		this.nationalOrigin = nationalOrigin;
	}

	public String getManufacturer() {
		return manufacturer;
	}

	public void setManufacturer(String manufacturer) {
		this.manufacturer = manufacturer;
	}

	public String getDesigner() {
		return designer;
	}

	public void setDesigner(String designer) {
		this.designer = designer;
	}

	public String getPrimaryUser() {
		return primaryUser;
	}

	public void setPrimaryUser(String primaryUser) {
		this.primaryUser = primaryUser;
	}

	@Override
	public String toString() {
		return "Rafale [fighterId=" + fighterId + ", model=" + model + ", pilotName=" + pilotName + ", role=" + role
				+ ", nationalOrigin=" + nationalOrigin + ", manufacturer=" + manufacturer + ", designer=" + designer
				+ ", primaryUser=" + primaryUser + "]";
	}
	
}
