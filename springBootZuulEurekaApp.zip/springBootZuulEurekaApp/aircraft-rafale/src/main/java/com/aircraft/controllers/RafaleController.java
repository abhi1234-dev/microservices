package com.aircraft.controllers;

import java.util.LinkedList;
import java.util.List;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aircraft.model.Rafale;

@RestController
public class RafaleController {
	
	@GetMapping("/getRafaleMessage")
	public String getConfiguration(){
		return "This is a french made multi-role jet fighter";
	}
	
	@GetMapping("/getRafaleFighterDetails")
	public List<Rafale> getAllFighterDetails(){
	
		System.out.println("INDIAN AIR FORCE/n Sky is the limit");
		System.out.println("Getting details of Rafale present in Pathankot Airbase.....");
		LinkedList<Rafale> rafaleRepo=new LinkedList<>();
		Rafale rafale=new Rafale();
		rafale.setFighterId(001);
		rafale.setModel("Rafale B");
		rafale.setPilotName("Abhishek Kumar");
		rafale.setRole("Multirole fighter");
		rafale.setNationalOrigin("France");
		rafale.setManufacturer("Dassault Aviation");
		rafale.setDesigner("Dassault Aviation");
		rafale.setPrimaryUser("French Air Force");
		Rafale rafale2=new Rafale();
		rafale2.setFighterId(002);
		rafale2.setModel("Rafale B");
		rafale2.setPilotName("Subramanya L");
		rafale2.setRole("Multirole fighter");
		rafale2.setNationalOrigin("France");
		rafale2.setManufacturer("Dassault Aviation");
		rafale2.setDesigner("Dassault Aviation");
		rafale2.setPrimaryUser("French Air Force");
		
		rafaleRepo.add(rafale);
		rafaleRepo.add(rafale2);
		
		return rafaleRepo;
	}

}
