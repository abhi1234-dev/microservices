package com.aircraft.controllers;

import java.util.LinkedList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.aircraft.model.Su30Mki;


@RestController
public class SukhoiController {

	
	@GetMapping("/startSu30Mki")
	public String initializeSu30Mki(){
		callTheAircraftMaintenanceTeam();
		return "Su30Mki is ready to take off";
	}

	private void callTheAircraftMaintenanceTeam() {

		System.out.println("Send Emergency calls to everyone in the aircraft maintenance team for making the fighter ready");
	}
	@GetMapping("/getSukhoiFighterDetails")
	public List<Su30Mki> getAllFighterDetails(){
		System.out.println("INDIAN AIR FORCE/n Sky is the limit");
		System.out.println("Getting details of Su30Mki present in Pathankot Airbase.....");
		LinkedList<Su30Mki> su30Repo=new LinkedList<>();
		Su30Mki sukhoi=new Su30Mki();
		sukhoi.setFighterId(001);
		sukhoi.setModel("Su30Mki");
		sukhoi.setPilotName("Abhishek Kumar");
		sukhoi.setRole("Multirole air superiority fighter");
		sukhoi.setNationalOrigin("Russia/India");
		sukhoi.setManufacturer("Hindustan Aeronautics Limited");
		sukhoi.setDesigner("Sukhoi");
		sukhoi.setPrimaryUser("Indian Air Force");
		Su30Mki sukhoi2=new Su30Mki();
		sukhoi2.setFighterId(002);
		sukhoi2.setModel("Su30Mki");
		sukhoi2.setPilotName("Subramanya L");
		sukhoi2.setRole("Multirole air superiority fighter");
		sukhoi2.setNationalOrigin("Russia/India");
		sukhoi2.setManufacturer("Hindustan Aeronautics Limited");
		sukhoi2.setDesigner("Sukhoi");
		sukhoi2.setPrimaryUser("Indian Air Force");
		
		su30Repo.add(sukhoi);
		su30Repo.add(sukhoi2);
		
		return su30Repo;
				
		
	}
}
