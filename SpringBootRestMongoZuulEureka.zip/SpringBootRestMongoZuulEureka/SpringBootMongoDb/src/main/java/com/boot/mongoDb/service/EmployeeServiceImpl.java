package com.boot.mongoDb.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.boot.mongoDb.model.Employee;
import com.boot.mongoDb.repository.EmployeeDao;
@Service
public class EmployeeServiceImpl implements EmployeeService{

	@Autowired
	EmployeeDao empDao;
	
	@Override
	public void createEmployees(List<Employee> emp) {
		empDao.saveAll(emp);
	}

	@Override
	public Collection<Employee> getAllEmployees() {
		return empDao.findAll();
	}

	@Override
	public Optional<Employee> findEmpById(int id) {
		return empDao.findById(id);
	}

	@Override
	public void updateEmployee(Employee e) {
		empDao.save(e);
	}

	@Override
	public void deleteEmployeeById(int id) {
		empDao.deleteById(id);
	}

	@Override
	public void deleteAllEmp() {
		empDao.deleteAll();
	}

}
