package com.boot.mongoDb.controller;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.boot.mongoDb.model.Employee;
import com.boot.mongoDb.service.EmployeeService;

@RestController
@RequestMapping(value="/api/mongo/emp")
public class EmployeeController {
	@Autowired
	EmployeeService service;
	
	private final Logger logger=LoggerFactory.getLogger(this.getClass());

	@PostMapping(value="/create")
	public String create(@RequestBody List<Employee> emp){
		logger.debug("Saving Employees");
		service.createEmployees(emp);
		return "Records Created";
	}
	@GetMapping("/getAllEmployees")
	public Collection<Employee> getAll(){
		logger.debug("Rtrieving Employees");
		return service.getAllEmployees();
	}
	@GetMapping("/getById/{employeeId}")
	public Optional<Employee> getById(@PathVariable(value="employeeId")int id){
		logger.debug("Getting Employee with empId:",id);
		return service.findEmpById(id);
	}
	@PutMapping("update/{employeeId}")
	public String update(@PathVariable(value="employeeId")int id,@RequestBody Employee e){
		logger.debug("Updating Employee");
		e.setId(id);
		service.updateEmployee(e);
		return "Employee Record has been updated";
	}
	@DeleteMapping("/delete/{employeeId}")
	public String delete(@PathVariable(value="employeeId")int id){
		logger.debug("Deleting employee with empId:",id);
		service.deleteEmployeeById(id);
		return "Empoyee with id:"+"has been deleted";
	}
	@DeleteMapping("/deleteAll")
	public String deleteAll(){
		logger.debug("Deleting all employees");
		service.deleteAllEmp();
		return "All Employee records has been deleted";
	}
	
}
