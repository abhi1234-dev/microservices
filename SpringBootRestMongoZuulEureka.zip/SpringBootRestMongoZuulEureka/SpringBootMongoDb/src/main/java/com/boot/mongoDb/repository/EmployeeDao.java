package com.boot.mongoDb.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.boot.mongoDb.model.Employee;

@Repository
public interface EmployeeDao extends MongoRepository<Employee, Integer>{

}
