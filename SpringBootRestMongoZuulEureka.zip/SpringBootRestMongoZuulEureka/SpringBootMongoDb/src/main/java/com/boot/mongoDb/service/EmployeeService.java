package com.boot.mongoDb.service;

import java.util.Collection;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Service;

import com.boot.mongoDb.model.Employee;

@Service
public interface EmployeeService {

	//method to create new Employee
	public void createEmployees(List<Employee> emp);
	public Collection<Employee> getAllEmployees();
    //method to fetch employee by Id
	public Optional<Employee> findEmpById(int id);
    //method to update employee by id
	public void updateEmployee(Employee e);
    //method to delete employee by id
	public void deleteEmployeeById(int id);
    //method to delete all employees
	public void deleteAllEmp();

}
